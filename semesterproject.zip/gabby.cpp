#include<iostream>
using namespace std;
int main(){
	int a,b,c,d,score;
	string student_name;
	cout<<"Enter your full name: ";
	getline(cin,student_name);
	
	cout<<"  *******NOTE: No cheating is allow in this exams********\n";
	system("pause");
	
			//FIRST QUESTION
	cout<<"\nQ1. Who is the most corrupt president on earth\n";
	cout<<"1. TRAMP\n";
	cout<<"2. Poti\n";
	cout<<"3. Nana Addo\n";
	cout<<"4. Boresa\n";
	cout<<" select your answer: ";
	cin>>a;
	
			//SECOND QUESTION
	cout<<"\nQ2. Who is the most dangours president on earth\n";
	cout<<"1. TRAMP\n";
	cout<<"2. Poti\n";
	cout<<"3. Nana Addo\n";
	cout<<"4. Boresa\n";
	cout<<" select your answer: ";
	cin>>b;
	
						//THIRD QUESTION
						Q3:
	cout<<"\nQ3. Who is the most dangours president on earth\n";
	cout<<"1. TRAMP\n";
	cout<<"2. Poti\n";
	cout<<"3. Nana Addo\n";
	cout<<"4. Boresa\n";
	cout<<" select your answer: ";
	cin>>c;
	
						//LAST QUESTION
	cout<<"\nq 3Q4. Who is the most dangours president on earth\n";
	cout<<"1. TRAMP\n";
	cout<<"2. Poti\n";
	cout<<"3. Nana Addo\n";
	cout<<"4. Boresa\n";
	cout<<" select your answer: ";
	cin>>d;
	
	int option[4]={a,b,c,d};
	int answer[4]={1,1,1,1};
	for(int i=0;i<4;i++){
		if(option[i]==answer[i]){
			score++;
		}
		else{
			score+=0;
		}
	}
	 
	  
	 cout<<endl<<"\n**************Results**************************"<<endl<<endl;
	 cout<<"  You score: "<<score<<endl;
	 if(score>=2){
	 	cout<<"   Comment: Well done!"<<endl;
	 }
	 else{
	 	 cout<<"  Comment: Sit Up"<<endl;
	 }
	 cout<<"   Student: "<<student_name<<endl;
  }
